import java.util.*;
import java.util.Random;
public class Digit4_5_6_7
{
   public int digit4_5_6_7Get()
   {
       int digit4_5_6_7;
       
       Random generator = new Random();
       
       digit4_5_6_7 = generator.nextInt(10);
       
       return digit4_5_6_7;
   }
}

