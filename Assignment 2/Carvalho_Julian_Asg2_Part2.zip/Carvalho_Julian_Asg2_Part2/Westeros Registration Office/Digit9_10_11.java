import java.util.*;
import java.util.Random;
public class Digit9_10_11
{
   public int digit9_10_11Get()
   {
       int digit9_10_11;
       
       Random generator = new Random();
       
       digit9_10_11 = generator.nextInt(10);
       
       return digit9_10_11;
   }
}
